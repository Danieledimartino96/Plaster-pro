// Service worker per funzionalità offline
const CACHE_NAME = 'plaster-pro-v3';

// Asset da memorizzare nella cache all'installazione
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icons/icon-72x72.png',
  '/icons/icon-96x96.png',
  '/icons/icon-128x128.png',
  '/icons/icon-144x144.png',
  '/icons/icon-152x152.png',
  '/icons/icon-192x192.png',
  '/icons/icon-384x384.png',
  '/icons/icon-512x512.png',
  '/icons/splash-640x1136.png',
  '/icons/splash-750x1334.png',
  '/icons/splash-1242x2208.png',
  '/icons/splash-1125x2436.png',
  '/icons/splash-1536x2048.png',
  '/icons/splash-1668x2224.png',
  '/icons/splash-2048x2732.png',
  'https://fonts.googleapis.com/css2?family=SF+Pro+Display:wght@300;400;500;600&display=swap',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
  'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js'
];

// Evento install - memorizza nella cache gli asset statici
self.addEventListener('install', event => {
  console.log('[Service Worker] Installazione in corso');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('[Service Worker] Cache aperta');
        return cache.addAll(STATIC_ASSETS);
      })
      .then(() => {
        console.log('[Service Worker] Installazione completata, skip waiting');
        return self.skipWaiting();
      })
  );
});

// Evento activate - pulisce le cache vecchie
self.addEventListener('activate', event => {
  console.log('[Service Worker] Attivazione in corso');
  event.waitUntil(
    caches.keys()
      .then(cacheNames => {
        return Promise.all(
          cacheNames.filter(cacheName => {
            return cacheName !== CACHE_NAME;
          }).map(cacheName => {
            console.log('[Service Worker] Eliminazione cache vecchia:', cacheName);
            return caches.delete(cacheName);
          })
        );
      })
      .then(() => {
        console.log('[Service Worker] Attivazione completata, clients claimed');
        return self.clients.claim();
      })
  );
});

// Evento fetch - serve dalla cache o dalla rete
self.addEventListener('fetch', event => {
  // Salta richieste non GET e richieste API
  if (event.request.method !== 'GET' || event.request.url.includes('/api/')) {
    return;
  }

  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Restituisce la risposta dalla cache se trovata
        if (response) {
          console.log('[Service Worker] Risposta dalla cache per:', event.request.url);
          return response;
        }

        // Clona la richiesta poiché può essere usata solo una volta
        const fetchRequest = event.request.clone();

        // Prova a recuperare dalla rete
        return fetch(fetchRequest)
          .then(response => {
            // Non memorizza nella cache risposte non valide
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }

            // Clona la risposta poiché può essere usata solo una volta
            const responseToCache = response.clone();

            // Memorizza la risposta nella cache
            caches.open(CACHE_NAME)
              .then(cache => {
                console.log('[Service Worker] Memorizzazione nella cache di:', event.request.url);
                cache.put(event.request, responseToCache);
              });

            return response;
          })
          .catch(error => {
            console.log('[Service Worker] Errore di fetch:', error);
            // Se offline e non in cache, serve una fallback per richieste HTML
            if (event.request.headers.get('accept')?.includes('text/html')) {
              console.log('[Service Worker] Fallback HTML per:', event.request.url);
              return caches.match('/');
            }
            
            // Per altre risorse, restituisce un messaggio di errore
            return new Response('Errore di rete. Verifica la connessione.', 
              { status: 408, headers: { 'Content-Type': 'text/plain' } 
            });
          });
      })
  );
});

// Gestione notifiche push
self.addEventListener('push', event => {
  console.log('[Service Worker] Notifica push ricevuta:', event);
  
  if (!event.data) return;

  try {
    const data = event.data.json();
    const options = {
      body: data.body || 'Nuovo aggiornamento disponibile',
      icon: data.icon || '/icons/icon-192x192.png',
      badge: '/icons/icon-72x72.png',
      vibrate: [100, 50, 100],
      data: {
        url: data.url || '/'
      }
    };

    event.waitUntil(
      self.registration.showNotification(data.title || 'PLASTER PRO', options)
    );
  } catch (error) {
    console.error('[Service Worker] Errore nella gestione della notifica push:', error);
  }
});

// Gestione click sulla notifica
self.addEventListener('notificationclick', event => {
  console.log('[Service Worker] Click sulla notifica');
  
  // Chiude la notifica
  event.notification.close();

  // Apre o focalizza la finestra quando si clicca sulla notifica
  event.waitUntil(
    self.clients.matchAll({ type: 'window' })
      .then(clients => {
        const url = event.notification.data?.url || '/';
        
        // Se una finestra è già aperta, la focalizza
        for (const client of clients) {
          if (client.url === url && 'focus' in client) {
            return client.focus();
          }
        }
        
        // Altrimenti apre una nuova finestra
        if (self.clients.openWindow) {
          return self.clients.openWindow(url);
        }
      })
  );
});