import { useProject } from "@/hooks/useProject.tsx";
import { useTranslation } from "@/lib/i18n.tsx";
import { Room } from "@shared/schema";
import { formatCurrency, formatNumber } from "@/lib/utils";
import Measurement from "./Measurement";
import { CSSProperties, useEffect } from "react";

interface RoomCardProps {
  room: Room;
  index: number;
  style?: CSSProperties;
}

export default function RoomCard({ room, index, style }: RoomCardProps) {
  const { 
    updateRoom, 
    deleteRoom, 
    duplicateRoom, 
    addMeasurement,
    calculateProject
  } = useProject();
  const { t } = useTranslation();

  // Recalculate when measurements change
  useEffect(() => {
    calculateProject();
  }, [room.measurements, calculateProject]);

  return (
    <div className="animate-[slideIn_0.5s_forwards] room-card" style={style} data-room-id={room.id}>
      <div className="bg-white dark:bg-stone-900 backdrop-blur-xl rounded-2xl shadow-lg border border-gray-200 dark:border-stone-800 overflow-hidden transform transition-transform duration-300 hover:-translate-y-1">
        <div className="p-4 flex justify-between items-center border-b border-gray-200 dark:border-stone-800">
          <div className="flex-grow">
            <input 
              type="text" 
              className="w-full py-2 px-3 bg-transparent dark:text-white text-lg font-medium rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent transition-all"
              value={room.name}
              placeholder="Nome stanza"
              onChange={(e) => updateRoom(room.id, { name: e.target.value })}
            />
          </div>
          <div className="flex gap-2">
            <button 
              onClick={() => duplicateRoom(room.id)}
              className="text-blue-500 dark:text-blue-400 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-stone-800 transition-colors"
              aria-label="Duplica stanza"
            >
              <i className="fas fa-copy"></i>
            </button>
            <button 
              onClick={() => {
                if (confirm("Vuoi eliminare questa stanza?")) {
                  deleteRoom(room.id);
                }
              }}
              className="text-red-500 dark:text-red-400 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-stone-800 transition-colors"
              aria-label="Elimina stanza"
            >
              <i className="fas fa-trash-alt"></i>
            </button>
          </div>
        </div>
        
        <div className="p-5">
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-4 flex items-center gap-2">
            <i className="fas fa-ruler-combined"></i>
            {t("room.measurements")}
          </h3>
          
          <div className="space-y-4">
            {room.measurements.map((measurement, idx) => (
              <Measurement 
                key={measurement.id} 
                roomId={room.id} 
                measurement={measurement}
                index={idx}
              />
            ))}
          </div>
          
          <button 
            onClick={() => addMeasurement(room.id)}
            className="flex items-center gap-2 mt-4 px-4 py-2 rounded-lg text-blue-500 dark:text-blue-400 border border-dashed border-blue-500 dark:border-blue-400 bg-blue-50 dark:bg-blue-900/10 hover:bg-blue-100 dark:hover:bg-blue-900/20 transition-colors"
          >
            <i className="fas fa-plus"></i>
            <span>{t("room.addMeasurement")}</span>
          </button>
        </div>
        
        <div className="bg-gray-50 dark:bg-stone-800 p-5 border-t border-gray-200 dark:border-stone-700">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="col-span-2 space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-700 dark:text-gray-300">{t("summary.totalWalls")}:</span>
                <span className="text-gray-900 dark:text-white">{formatNumber(room.wallArea || 0, "m²")}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-700 dark:text-gray-300">{t("summary.totalCeilings")}:</span>
                <span className="text-gray-900 dark:text-white">{formatNumber(room.ceilingArea || 0, "m²")}</span>
              </div>
              <div className="flex justify-between font-medium pt-2 border-t border-gray-200 dark:border-stone-700">
                <span className="text-gray-900 dark:text-white">{t("summary.totalArea")}:</span>
                <span className="text-gray-900 dark:text-white">{formatNumber(room.totalArea || 0, "m²")}</span>
              </div>
            </div>
            <div className="bg-white dark:bg-stone-900 rounded-xl p-4 border border-gray-200 dark:border-stone-700">
              <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Materiale necessario</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-700 dark:text-gray-300">Sacchi:</span>
                  <span className="text-gray-900 dark:text-white">{room.materials?.bags || 0} sacchi</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-700 dark:text-gray-300">Costo:</span>
                  <span className="text-gray-900 dark:text-white">{formatCurrency(room.materials?.cost || 0)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
