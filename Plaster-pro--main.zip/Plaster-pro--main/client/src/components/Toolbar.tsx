import { useProject } from "@/hooks/useProject.tsx";
import { useTheme } from "@/hooks/useTheme.tsx";
import { useTranslation } from "@/lib/i18n.tsx";
import { useLocation } from "wouter";

export default function Toolbar() {
  const { newProject, saveProject, exportPdf, isOnline } = useProject();
  const { theme, setTheme, resolvedTheme } = useTheme();
  const { t } = useTranslation();
  const [location, setLocation] = useLocation();

  const handleThemeToggle = () => {
    setTheme(resolvedTheme === "dark" ? "light" : "dark");
  };

  const navigateToHistory = () => {
    setLocation("/history");
  };

  const navigateToHome = () => {
    setLocation("/");
  };

  return (
    <div className="mb-6 animate-[slideIn_0.5s_forwards] animation-delay-100">
      <div className="bg-white dark:bg-stone-900 backdrop-blur-xl rounded-2xl shadow-lg border border-gray-200 dark:border-stone-800 p-4 flex flex-wrap justify-between items-center gap-4">
        <div className="flex flex-wrap gap-3">
          <button
            onClick={newProject}
            className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 dark:bg-blue-600 text-white px-4 py-3 rounded-xl font-medium text-sm transition-all duration-300 hover:shadow-lg shadow-md transform hover:-translate-y-0.5 active:translate-y-0"
          >
            <i className="fas fa-plus"></i>
            <span>{t("toolbar.newProject")}</span>
          </button>
          
          <button
            onClick={() => saveProject()}
            className="flex items-center gap-2 bg-green-500 hover:bg-green-600 dark:bg-green-600 text-white px-4 py-3 rounded-xl font-medium text-sm transition-all duration-300 hover:shadow-lg shadow-md transform hover:-translate-y-0.5 active:translate-y-0"
          >
            <i className="fas fa-save"></i>
            <span>{t("toolbar.saveProject")}</span>
          </button>
          
          {location === "/" ? (
            <button
              onClick={navigateToHistory}
              className="flex items-center gap-2 bg-amber-500 hover:bg-amber-600 dark:bg-amber-600 text-white px-4 py-3 rounded-xl font-medium text-sm transition-all duration-300 hover:shadow-lg shadow-md transform hover:-translate-y-0.5 active:translate-y-0"
            >
              <i className="fas fa-folder-open"></i>
              <span>{t("toolbar.loadProject")}</span>
            </button>
          ) : (
            <button
              onClick={navigateToHome}
              className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 dark:bg-blue-600 text-white px-4 py-3 rounded-xl font-medium text-sm transition-all duration-300 hover:shadow-lg shadow-md transform hover:-translate-y-0.5 active:translate-y-0"
            >
              <i className="fas fa-home"></i>
              <span>Home</span>
            </button>
          )}
        </div>
        
        <div className="flex flex-wrap gap-3">
          <button
            onClick={exportPdf}
            className="flex items-center gap-2 bg-white dark:bg-stone-800 hover:bg-gray-50 dark:hover:bg-stone-700 text-gray-900 dark:text-white border border-gray-200 dark:border-stone-700 px-4 py-3 rounded-xl font-medium text-sm transition-all duration-300 transform hover:-translate-y-0.5 active:translate-y-0"
          >
            <i className="fas fa-file-pdf text-red-500 dark:text-red-400"></i>
            <span>{t("toolbar.exportPdf")}</span>
          </button>
          
          {location === "/" && (
            <button
              onClick={navigateToHistory}
              className="flex items-center gap-2 bg-white dark:bg-stone-800 hover:bg-gray-50 dark:hover:bg-stone-700 text-gray-900 dark:text-white border border-gray-200 dark:border-stone-700 px-4 py-3 rounded-xl font-medium text-sm transition-all duration-300 transform hover:-translate-y-0.5 active:translate-y-0"
            >
              <i className="fas fa-history text-gray-500 dark:text-gray-400"></i>
              <span>{t("toolbar.history")}</span>
            </button>
          )}
          
          <button
            onClick={handleThemeToggle}
            className="bg-white dark:bg-stone-800 hover:bg-gray-50 dark:hover:bg-stone-700 text-gray-900 dark:text-white border border-gray-200 dark:border-stone-700 p-3 rounded-xl font-medium text-sm transition-all duration-300 transform hover:-translate-y-0.5 active:translate-y-0"
            aria-label="Toggle dark mode"
          >
            {resolvedTheme === "dark" ? (
              <i className="fas fa-sun"></i>
            ) : (
              <i className="fas fa-moon"></i>
            )}
          </button>
          
          {!isOnline && (
            <div className="bg-amber-100 dark:bg-amber-900 text-amber-800 dark:text-amber-200 px-3 py-2 rounded-xl text-sm flex items-center gap-1">
              <i className="fas fa-wifi-slash"></i>
              <span>Offline</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
