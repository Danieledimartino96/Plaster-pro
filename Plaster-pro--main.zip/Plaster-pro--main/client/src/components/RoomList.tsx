import { useProject } from "@/hooks/useProject.tsx";
import { useTranslation } from "@/lib/i18n.tsx";
import RoomCard from "./RoomCard";

export default function RoomList() {
  const { project, addRoom } = useProject();
  const { t } = useTranslation();

  return (
    <div>
      <div id="roomsList" className="space-y-6">
        {project.rooms.map((room, index) => (
          <RoomCard 
            key={room.id} 
            room={room} 
            index={index}
            style={{ animationDelay: `${0.4 + index * 0.1}s` }}
          />
        ))}
      </div>
      
      <div className="mt-6 flex justify-center">
        <button 
          onClick={addRoom}
          className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 dark:bg-blue-600 text-white px-6 py-4 rounded-xl font-medium transition-all duration-300 hover:shadow-lg shadow-md transform hover:-translate-y-0.5 active:translate-y-0 animate-[slideIn_0.5s_forwards]"
          style={{ animationDelay: "0.6s" }}
        >
          <i className="fas fa-plus-circle"></i>
          <span>{t("room.addRoom")}</span>
        </button>
      </div>
    </div>
  );
}
