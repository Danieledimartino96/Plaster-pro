import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Home, History as HistoryIcon, Settings, Plus } from "lucide-react";
import { useTranslation } from "@/lib/i18n";

export function IOSNavbar({ title }: { title: string }) {
  const { t } = useTranslation();
  
  return (
    <div className="ios-navbar">
      <h1 className="text-lg font-semibold text-center flex-1">{title}</h1>
    </div>
  );
}

export function IOSTabBar() {
  const { t } = useTranslation();
  const [location] = useLocation();
  
  return (
    <div className="ios-tab-bar">
      <Link href="/">
        <a className="ios-tab-item">
          <Home className={`ios-tab-icon ${location === "/" ? "text-primary" : ""}`} />
          <span className={`ios-tab-label ${location === "/" ? "text-primary font-semibold" : ""}`}>
            {t("home")}
          </span>
        </a>
      </Link>
      
      <Link href="/create">
        <a className="ios-tab-item">
          <div className="bg-primary text-white rounded-full p-2">
            <Plus className="h-5 w-5" />
          </div>
          <span className="ios-tab-label">
            {t("new")}
          </span>
        </a>
      </Link>
      
      <Link href="/history">
        <a className="ios-tab-item">
          <HistoryIcon className={`ios-tab-icon ${location === "/history" ? "text-primary" : ""}`} />
          <span className={`ios-tab-label ${location === "/history" ? "text-primary font-semibold" : ""}`}>
            {t("history")}
          </span>
        </a>
      </Link>
    </div>
  );
}

// Wrapper layout per le pagine in stile iOS
export function IOSLayout({ 
  children, 
  title,
  showNavbar = true,
  showTabBar = true
}: { 
  children: React.ReactNode;
  title: string;
  showNavbar?: boolean;
  showTabBar?: boolean;
}) {
  return (
    <div className="ios-layout relative">
      {showNavbar && <IOSNavbar title={title} />}
      <main className={`ios-page ${!showNavbar ? 'pt-0' : ''} ${!showTabBar ? 'pb-6' : ''}`}>
        {children}
      </main>
      {showTabBar && <IOSTabBar />}
    </div>
  );
}

// Componente per mostrare un pulsante in stile iOS
export function IOSButton({ 
  children, 
  onClick, 
  variant = "primary" 
}: { 
  children: React.ReactNode; 
  onClick?: () => void; 
  variant?: "primary" | "secondary" | "danger" 
}) {
  const variantClasses = {
    primary: "bg-primary text-white",
    secondary: "bg-gray-200 text-gray-800",
    danger: "bg-red-500 text-white"
  };
  
  return (
    <button 
      className={`ios-button ${variantClasses[variant]} active:opacity-80`}
      onClick={onClick}
    >
      {children}
    </button>
  );
}

// Componente per mostrare una card in stile iOS
export function IOSCard({ 
  children, 
  className = "" 
}: { 
  children: React.ReactNode; 
  className?: string;
}) {
  return (
    <div className={`ios-card ${className}`}>
      {children}
    </div>
  );
}