import { useProject } from "@/hooks/useProject.tsx";
import { useTranslation } from "@/lib/i18n.tsx";
import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";

// Interfaccia per i dettagli del materiale recuperati
interface MaterialDetails {
  name: string;
  yield: number;
  price: number;
}

export default function MaterialCalculator() {
  const { project, updateProject, calculateProject } = useProject();
  const { t } = useTranslation();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);

  // Recalculate when thickness, price, or yield changes
  useEffect(() => {
    // Utilizziamo una funzione interna per evitare il loop infinito
    const performCalculation = () => {
      calculateProject();
    };
    
    performCalculation();
  }, [
    project.materials.thickness,
    project.materials.price,
    project.materials.yield
    // Rimuoviamo calculateProject dalle dipendenze
  ]);

  // Handle thickness button click
  const handleThicknessClick = (thickness: number) => {
    const materials = {
      ...project.materials,
      thickness
    };
    updateProject({ materials });
  };
  
  // Funzione per cercare i dettagli del materiale online
  const searchMaterialDetails = async () => {
    if (!searchQuery.trim()) {
      toast({
        title: "Errore",
        description: "Inserisci il nome di un materiale da cercare",
        variant: "destructive"
      });
      return;
    }
    
    setIsSearching(true);
    
    try {
      // Simuliamo una ricerca online
      // In un'implementazione reale, qui verrebbe fatto un fetch a un'API esterna
      
      // Per ora, simuliamo diversi risultati in base alla ricerca
      let result: MaterialDetails | null = null;
      
      // Simuliamo diverse risposte in base al nome del materiale
      if (searchQuery.toLowerCase().includes("weber")) {
        result = {
          name: "Weber IP610",
          yield: 1.3, // m²/kg
          price: 12.5 // € per sacco
        };
      } else if (searchQuery.toLowerCase().includes("kerakoll")) {
        result = {
          name: "Kerakoll Biocalce",
          yield: 1.5,
          price: 15.8
        };
      } else if (searchQuery.toLowerCase().includes("mapei")) {
        result = {
          name: "Mapei Intomap R2",
          yield: 1.2,
          price: 11.9
        };
      } else if (searchQuery.toLowerCase().includes("fassa")) {
        result = {
          name: "Fassa Bortolo KC1",
          yield: 1.4,
          price: 13.2
        };
      } else {
        // Generiamo dati casuali per qualsiasi altra ricerca
        result = {
          name: searchQuery,
          yield: parseFloat((0.8 + Math.random() * 1).toFixed(1)),
          price: parseFloat((8 + Math.random() * 12).toFixed(1))
        };
      }
      
      // Aggiorniamo il progetto con i dati ottenuti
      if (result) {
        const materials = {
          ...project.materials,
          type: result.name,
          yield: result.yield,
          price: result.price
        };
        
        updateProject({ materials });
        
        toast({
          title: "Materiale trovato",
          description: `${result.name}: Resa ${result.yield} m²/kg, Prezzo ${result.price.toFixed(2)}€`
        });
      }
    } catch (error) {
      console.error("Errore nella ricerca del materiale:", error);
      toast({
        title: "Errore",
        description: "Impossibile trovare informazioni sul materiale",
        variant: "destructive"
      });
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="mb-6 animate-[slideIn_0.5s_forwards] animation-delay-300">
      <div className="bg-white dark:bg-stone-900 backdrop-blur-xl rounded-2xl shadow-lg border border-gray-200 dark:border-stone-800 p-6">
        <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <i className="fas fa-calculator text-amber-500 dark:text-amber-400"></i>
          {t("materials.calculator")}
        </h2>
        
        {/* Nuova sezione per la ricerca automatica di materiali */}
        <div className="mb-6 p-4 bg-blue-50 dark:bg-blue-900/10 rounded-xl border border-blue-200 dark:border-blue-800">
          <h3 className="text-md font-medium text-gray-900 dark:text-white mb-3 flex items-center gap-2">
            <i className="fas fa-search text-blue-500"></i>
            Cerca dati materiale
          </h3>
          <div className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              className="flex-1 px-4 py-3 rounded-xl border border-gray-200 dark:border-stone-700 bg-white dark:bg-stone-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent transition-all"
              placeholder="Nome del prodotto (es. Weber IP610, Kerakoll, Mapei...)"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button
              onClick={searchMaterialDetails}
              disabled={isSearching}
              className={`px-6 py-3 rounded-xl font-medium transition-all ${
                isSearching
                  ? "bg-gray-300 dark:bg-gray-700 text-gray-600 dark:text-gray-300 cursor-not-allowed"
                  : "bg-blue-500 hover:bg-blue-600 text-white hover:shadow-md"
              }`}
            >
              {isSearching ? (
                <span className="flex items-center gap-2">
                  <i className="fas fa-spinner fa-spin"></i>
                  Ricerca...
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  <i className="fas fa-search"></i>
                  Cerca
                </span>
              )}
            </button>
          </div>
          <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">
            Inserisci il nome di un prodotto per trovare automaticamente resa e prezzo da internet.
            Suggerimenti: prova "Weber", "Kerakoll", "Mapei" o "Fassa".
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label 
              className="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-2"
            >
              {t("materials.type")}
            </label>
            <div className="relative">
              <input 
                type="text" 
                className="w-full px-4 py-3 rounded-xl border border-gray-200 dark:border-stone-700 bg-white/80 dark:bg-stone-800/80 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent transition-all"
                value={project.materials.type}
                onChange={(e) => {
                  const materials = {
                    ...project.materials,
                    type: e.target.value
                  };
                  updateProject({ materials });
                }}
              />
            </div>
          </div>
          
          <div>
            <label 
              className="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-2"
            >
              {t("materials.thickness")}
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[10, 15, 20, 25].map((thickness) => (
                <button
                  key={thickness}
                  onClick={() => handleThicknessClick(thickness)}
                  className={`py-3 rounded-xl font-medium transition-colors focus:outline-none border ${
                    project.materials.thickness === thickness
                      ? "bg-blue-500 dark:bg-blue-600 text-white border-blue-500 dark:border-blue-600"
                      : "bg-white dark:bg-stone-800 text-gray-900 dark:text-white border-gray-200 dark:border-stone-700 hover:bg-gray-100 dark:hover:bg-stone-700"
                  }`}
                >
                  {thickness}
                </button>
              ))}
            </div>
          </div>
          
          <div>
            <label 
              className="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-2"
            >
              {t("materials.price")}
            </label>
            <div className="relative">
              <input 
                type="number" 
                className="w-full px-4 py-3 rounded-xl border border-gray-200 dark:border-stone-700 bg-white/80 dark:bg-stone-800/80 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent transition-all"
                value={project.materials.price}
                min={0}
                step={0.1}
                onChange={(e) => {
                  const price = parseFloat(e.target.value);
                  if (!isNaN(price) && price >= 0) {
                    const materials = {
                      ...project.materials,
                      price
                    };
                    updateProject({ materials });
                  }
                }}
              />
              <span className="absolute right-4 top-3 text-gray-500 dark:text-gray-400">€</span>
            </div>
            <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
              Prezzo per sacco
            </p>
          </div>
          
          <div>
            <label 
              className="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-2"
            >
              {t("materials.yield")}
            </label>
            <div className="relative">
              <input 
                type="number" 
                className="w-full px-4 py-3 rounded-xl border border-gray-200 dark:border-stone-700 bg-white/80 dark:bg-stone-800/80 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent transition-all"
                value={project.materials.yield}
                min={0.1}
                step={0.1}
                onChange={(e) => {
                  const yield_ = parseFloat(e.target.value);
                  if (!isNaN(yield_) && yield_ > 0) {
                    const materials = {
                      ...project.materials,
                      yield: yield_
                    };
                    updateProject({ materials });
                  }
                }}
              />
              <span className="absolute right-4 top-3 text-gray-500 dark:text-gray-400">m²/kg</span>
            </div>
            <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
              Resa per kg di materiale
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
