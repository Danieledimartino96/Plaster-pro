import { useProject } from "@/hooks/useProject.tsx";
import { useTranslation } from "@/lib/i18n.tsx";
import { useEffect } from "react";

export default function ProjectDetails() {
  const { project, updateProject } = useProject();
  const { t } = useTranslation();

  // Set default date if not set
  useEffect(() => {
    if (!project.date) {
      updateProject({ date: new Date().toISOString().split('T')[0] });
    }
  }, [project.date, updateProject]);

  return (
    <div className="mb-6 animate-[slideIn_0.5s_forwards] animation-delay-200">
      <div className="bg-white dark:bg-stone-900 backdrop-blur-xl rounded-2xl shadow-lg border border-gray-200 dark:border-stone-800 p-6">
        <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <i className="fas fa-clipboard-list text-blue-500 dark:text-blue-400"></i>
          {t("project.details")}
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label 
              htmlFor="projectName" 
              className="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-2"
            >
              {t("project.name")}
            </label>
            <input 
              type="text" 
              id="projectName" 
              placeholder="Inserisci il nome del progetto" 
              className="w-full px-4 py-3 rounded-xl border border-gray-200 dark:border-stone-700 bg-white/80 dark:bg-stone-800/80 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent transition-all"
              value={project.name}
              onChange={(e) => updateProject({ name: e.target.value })}
            />
          </div>
          
          <div>
            <label 
              htmlFor="clientName" 
              className="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-2"
            >
              {t("project.client")}
            </label>
            <input 
              type="text" 
              id="clientName" 
              placeholder="Inserisci il nome del cliente" 
              className="w-full px-4 py-3 rounded-xl border border-gray-200 dark:border-stone-700 bg-white/80 dark:bg-stone-800/80 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent transition-all"
              value={project.client}
              onChange={(e) => updateProject({ client: e.target.value })}
            />
          </div>
          
          <div>
            <label 
              htmlFor="projectAddress" 
              className="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-2"
            >
              {t("project.address")}
            </label>
            <input 
              type="text" 
              id="projectAddress" 
              placeholder="Inserisci l'indirizzo del cantiere" 
              className="w-full px-4 py-3 rounded-xl border border-gray-200 dark:border-stone-700 bg-white/80 dark:bg-stone-800/80 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent transition-all"
              value={project.address}
              onChange={(e) => updateProject({ address: e.target.value })}
            />
          </div>
          
          <div>
            <label 
              htmlFor="projectDate" 
              className="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-2"
            >
              {t("project.date")}
            </label>
            <input 
              type="date" 
              id="projectDate" 
              className="w-full px-4 py-3 rounded-xl border border-gray-200 dark:border-stone-700 bg-white/80 dark:bg-stone-800/80 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent transition-all"
              value={project.date}
              onChange={(e) => updateProject({ date: e.target.value })}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
