import { useProject } from "@/hooks/useProject.tsx";
import { useTranslation } from "@/lib/i18n.tsx";
import { formatCurrency, formatNumber } from "@/lib/utils";
import { useEffect } from "react";

export default function ProjectSummary() {
  const { project, calculateProject } = useProject();
  const { t } = useTranslation();
  
  // Ensure calculations are up to date
  useEffect(() => {
    calculateProject();
  }, [calculateProject]);
  
  // Calculate total areas for walls and ceilings
  const totalWallArea = project.rooms.reduce((sum, room) => sum + (room.wallArea || 0), 0);
  const totalCeilingArea = project.rooms.reduce((sum, room) => sum + (room.ceilingArea || 0), 0);
  const totalDeductions = project.rooms.reduce((sum, room) => 
    sum + room.measurements.reduce((s, m) => s + m.deductions, 0), 0);
  
  // Get material type display name
  const materialTypeMap: Record<string, string> = {
    standard: "Intonaco Standard",
    premixed: "Intonaco Premiscelato",
    lime: "Intonaco di Calce",
    cement: "Intonaco Cementizio",
    gypsum: "Intonaco di Gesso"
  };
  
  const materialType = materialTypeMap[project.materials.type] || project.materials.type;
  
  // Share on WhatsApp
  const shareOnWhatsApp = () => {
    const text = encodeURIComponent(
      `Progetto PLASTER PRO: ${project.name}\n` +
      `Cliente: ${project.client}\n` +
      `Superficie totale: ${formatNumber(project.totalArea || 0, "m²")}\n` +
      `Costo materiali: ${formatCurrency(project.totalCost || 0)}`
    );
    window.open(`https://wa.me/?text=${text}`, '_blank');
  };

  return (
    <div className="mt-8 mb-6 animate-[slideIn_0.5s_forwards]" style={{ animationDelay: "0.7s" }}>
      <div className="bg-white dark:bg-stone-900 backdrop-blur-xl rounded-2xl shadow-lg border border-gray-200 dark:border-stone-800 p-6">
        <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <i className="fas fa-clipboard-check text-green-500 dark:text-green-400"></i>
          {t("summary.title")}
        </h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-gray-50 dark:bg-stone-800 rounded-xl p-5 border border-gray-200 dark:border-stone-700">
            <h3 className="text-md font-medium text-gray-900 dark:text-white mb-3">Dettagli superficie</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center py-2 border-b border-gray-200 dark:border-stone-700">
                <span className="text-gray-700 dark:text-gray-300">Numero di stanze:</span>
                <span className="text-gray-900 dark:text-white font-medium">{project.rooms.length}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-gray-200 dark:border-stone-700">
                <span className="text-gray-700 dark:text-gray-300">{t("summary.totalWalls")}:</span>
                <span className="text-gray-900 dark:text-white font-medium">{formatNumber(totalWallArea, "m²")}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-gray-200 dark:border-stone-700">
                <span className="text-gray-700 dark:text-gray-300">{t("summary.totalCeilings")}:</span>
                <span className="text-gray-900 dark:text-white font-medium">{formatNumber(totalCeilingArea, "m²")}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-gray-200 dark:border-stone-700">
                <span className="text-gray-700 dark:text-gray-300">Totale detrazioni (finestre, porte):</span>
                <span className="text-gray-900 dark:text-white font-medium">{formatNumber(totalDeductions, "m²")}</span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-gray-900 dark:text-white font-semibold">Superficie netta totale:</span>
                <span className="text-gray-900 dark:text-white font-semibold">{formatNumber(project.totalArea || 0, "m²")}</span>
              </div>
            </div>
          </div>
          
          <div className="bg-gradient-to-br from-blue-500/90 to-amber-500/90 dark:from-blue-600/90 dark:to-amber-600/90 rounded-xl p-5 text-white">
            <h3 className="text-md font-medium mb-3">Riepilogo materiali</h3>
            <div className="space-y-4">
              <div className="py-2 border-b border-white/20">
                <div className="grid grid-cols-2 gap-2">
                  <span>Tipo intonaco:</span>
                  <span className="font-medium text-right">{materialType}</span>
                </div>
              </div>
              <div className="py-2 border-b border-white/20">
                <div className="grid grid-cols-2 gap-2">
                  <span>Spessore:</span>
                  <span className="font-medium text-right">{project.materials.thickness} mm</span>
                </div>
              </div>
              <div className="py-2 border-b border-white/20">
                <div className="grid grid-cols-2 gap-2">
                  <span>{t("summary.bagsNeeded")}:</span>
                  <span className="font-medium text-right">{project.totalBags || 0} sacchi</span>
                </div>
              </div>
              <div className="py-2">
                <div className="grid grid-cols-2 gap-2">
                  <span>{t("summary.totalCost")}:</span>
                  <span className="font-medium text-right">{formatCurrency(project.totalCost || 0)}</span>
                </div>
              </div>
              
              <button 
                onClick={shareOnWhatsApp}
                className="mt-4 w-full flex items-center justify-center gap-2 bg-white/15 backdrop-blur-sm hover:bg-white/25 text-white border border-white/30 px-4 py-3 rounded-xl font-medium text-sm transition-all duration-300 transform hover:-translate-y-0.5 active:translate-y-0"
              >
                <i className="fab fa-whatsapp"></i>
                <span>{t("actions.share")}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
