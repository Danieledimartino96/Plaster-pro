import { useTranslation } from "@/lib/i18n.tsx";

export default function Header() {
  const { t } = useTranslation();

  return (
    <header className="mb-6 animate-[slideIn_0.5s_forwards]">
      <div className="relative bg-white dark:bg-stone-900 backdrop-blur-xl rounded-2xl shadow-lg overflow-hidden border border-gray-200 dark:border-stone-800">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 to-orange-500"></div>
        <div className="px-8 py-6">
          <h1 className="text-3xl font-semibold bg-gradient-to-r from-blue-500 to-orange-500 bg-clip-text text-transparent">
            {t("app.title")}
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mt-2">
            {t("app.subtitle")}
          </p>
        </div>
      </div>
    </header>
  );
}
