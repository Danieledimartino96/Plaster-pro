import { useProject } from "@/hooks/useProject.tsx";
import { useTranslation } from "@/lib/i18n.tsx";
import { Measurement as MeasurementType } from "@shared/schema";
import { formatNumber, calculateArea } from "@/lib/utils";
import { useState, useEffect, ChangeEvent } from "react";

interface MeasurementProps {
  roomId: string;
  measurement: MeasurementType;
  index: number;
}

export default function Measurement({ roomId, measurement, index }: MeasurementProps) {
  const { updateMeasurement, deleteMeasurement, toggleCeiling } = useProject();
  const { t } = useTranslation();
  
  // Local state for controlled inputs
  const [length, setLength] = useState(measurement.length);
  const [height, setHeight] = useState(measurement.height);
  const [deductions, setDeductions] = useState(measurement.deductions);
  
  // Calculate and update area when dimensions change
  useEffect(() => {
    const area = calculateArea({
      ...measurement,
      length,
      height,
      deductions
    });
    
    updateMeasurement(roomId, measurement.id, { area });
  }, [length, height, deductions, roomId, measurement, updateMeasurement]);
  
  // Handle input changes with validation
  const handleNumberChange = (
    setter: React.Dispatch<React.SetStateAction<number>>,
    value: string,
    field: keyof MeasurementType
  ) => {
    const numValue = parseFloat(value);
    if (!isNaN(numValue) && numValue >= 0) {
      setter(numValue);
      updateMeasurement(roomId, measurement.id, { [field]: numValue });
    }
  };

  return (
    <div className={`measurement-row bg-white dark:bg-stone-800 rounded-xl border border-gray-200 dark:border-stone-700 p-4 transition-all duration-300 hover:shadow-md ${
      measurement.isCeiling ? 'bg-blue-50 dark:bg-blue-900/10 border-l-4 border-l-blue-500' : ''
    }`}>
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-gray-500 dark:text-gray-400">
            {measurement.isCeiling ? t("room.ceiling") : `${t("room.wall")} ${index + 1}`}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => toggleCeiling(roomId, measurement.id)}
            className={`ceiling-toggle flex items-center gap-1 px-3 py-1 rounded-lg text-sm font-medium ${
              measurement.isCeiling 
                ? 'bg-blue-100 dark:bg-blue-900/20 text-blue-500 dark:text-blue-400' 
                : 'text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-stone-700'
            }`}
          >
            <i className="fas fa-home"></i>
            <span>{t("room.ceiling")}</span>
          </button>
          <button 
            onClick={() => deleteMeasurement(roomId, measurement.id)}
            className="text-red-500 dark:text-red-400 p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-stone-700 transition-colors"
            aria-label="Elimina misurazione"
          >
            <i className="fas fa-times"></i>
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-3">
        <div className="relative">
          <input 
            type="number" 
            placeholder="0" 
            value={length}
            min={0}
            step={0.1}
            className="w-full py-3 px-4 rounded-xl border border-gray-200 dark:border-stone-700 text-center focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent transition-all text-gray-900 dark:text-white bg-white dark:bg-stone-900"
            onChange={(e: ChangeEvent<HTMLInputElement>) => 
              handleNumberChange(setLength, e.target.value, 'length')
            }
          />
          <span className="absolute right-4 top-3 text-gray-500 dark:text-gray-400">m</span>
          <label className="block text-xs text-gray-500 dark:text-gray-400 mt-1 text-center">{t("room.length")}</label>
        </div>
        
        <div className="relative">
          <input 
            type="number" 
            placeholder="0" 
            value={height}
            min={0}
            step={0.1}
            className="w-full py-3 px-4 rounded-xl border border-gray-200 dark:border-stone-700 text-center focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent transition-all text-gray-900 dark:text-white bg-white dark:bg-stone-900"
            onChange={(e: ChangeEvent<HTMLInputElement>) => 
              handleNumberChange(setHeight, e.target.value, 'height')
            }
          />
          <span className="absolute right-4 top-3 text-gray-500 dark:text-gray-400">m</span>
          <label className="block text-xs text-gray-500 dark:text-gray-400 mt-1 text-center">{t("room.height")}</label>
        </div>
        
        <div className="relative">
          <input 
            type="number" 
            placeholder="0" 
            value={deductions}
            min={0}
            step={0.1}
            className="w-full py-3 px-4 rounded-xl border border-gray-200 dark:border-stone-700 text-center focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent transition-all text-gray-900 dark:text-white bg-white dark:bg-stone-900"
            onChange={(e: ChangeEvent<HTMLInputElement>) => 
              handleNumberChange(setDeductions, e.target.value, 'deductions')
            }
          />
          <span className="absolute right-4 top-3 text-gray-500 dark:text-gray-400">m²</span>
          <label className="block text-xs text-gray-500 dark:text-gray-400 mt-1 text-center">{t("room.deductions")}</label>
        </div>
        
        <div className="p-3 flex items-center justify-center bg-gray-50 dark:bg-stone-900 rounded-xl border border-gray-200 dark:border-stone-700">
          <div className="text-center">
            <span className="text-lg font-medium text-gray-900 dark:text-white">{formatNumber(measurement.area || 0, "", 2)}</span>
            <span className="text-gray-500 dark:text-gray-400 ml-1">m²</span>
            <label className="block text-xs text-gray-500 dark:text-gray-400 mt-1">{t("room.area")}</label>
          </div>
        </div>
      </div>
    </div>
  );
}
