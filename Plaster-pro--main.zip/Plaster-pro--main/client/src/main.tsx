import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { registerSW } from "./lib/utils";

// Register service worker for offline functionality
registerSW();

createRoot(document.getElementById("root")!).render(<App />);
