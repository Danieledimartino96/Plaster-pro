import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import History from "@/pages/history";
import { ThemeProvider } from "@/hooks/useTheme.tsx";
import { ProjectProvider } from "@/hooks/useProject.tsx";
import { useEffect } from "react";
import { I18nProvider } from "@/lib/i18n.tsx";
import { IOSLayout } from "@/components/IOSNavigation";
import { useTranslation } from "@/lib/i18n";

function Router() {
  const [location] = useLocation();
  const { t } = useTranslation();

  // Scroll to top on route change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);

  // Funzione per ottenere il titolo della pagina corrente
  const getPageTitle = () => {
    switch (location) {
      case "/":
        return "PLASTER PRO";
      case "/history":
        return t("project_history");
      default:
        return "PLASTER PRO";
    }
  };

  return (
    <IOSLayout title={getPageTitle()} showNavbar={true} showTabBar={true}>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/history" component={History} />
        <Route component={NotFound} />
      </Switch>
    </IOSLayout>
  );
}

function App() {
  // Effetto per impedire lo zoom su dispositivi mobili
  useEffect(() => {
    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length > 1) {
        e.preventDefault();
      }
    };

    // Previene il double-tap per zoom sui dispositivi iOS
    document.addEventListener('touchstart', handleTouchStart, { passive: false });
    
    return () => {
      document.removeEventListener('touchstart', handleTouchStart);
    };
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <I18nProvider>
        <ThemeProvider>
          <ProjectProvider>
            <Router />
            <Toaster />
          </ProjectProvider>
        </ThemeProvider>
      </I18nProvider>
    </QueryClientProvider>
  );
}

export default App;
