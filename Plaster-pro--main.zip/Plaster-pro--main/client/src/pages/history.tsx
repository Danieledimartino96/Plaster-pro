import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { getProjectHistory, getSavedProjectById, deleteSavedProject } from "@/lib/storage";
import { useProject } from "@/hooks/useProject.tsx";
import { useTranslation } from "@/lib/i18n.tsx";
import { formatCurrency, formatNumber } from "@/lib/utils";
import { HistoryItem } from "@/types";
import { useToast } from "@/hooks/use-toast";
import { IOSCard, IOSButton } from "@/components/IOSNavigation";
import { Folder, Calendar, User, Clock, Maximize2, CircleDollarSign, ArrowRight, Trash2 } from "lucide-react";

export default function History() {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const { setProject } = useProject();
  const [_, setLocation] = useLocation();
  const { t } = useTranslation();
  const { toast } = useToast();
  
  // Load history on mount
  useEffect(() => {
    const projectHistory = getProjectHistory();
    setHistory(projectHistory);
  }, []);
  
  // Load a project and navigate to home
  const handleLoadProject = (id: string) => {
    const project = getSavedProjectById(id);
    if (project) {
      setProject(project);
      
      toast({
        title: "Progetto caricato",
        description: "Il progetto è stato caricato con successo",
        variant: "default"
      });
      
      setLocation("/");
    } else {
      toast({
        title: "Errore",
        description: "Impossibile caricare il progetto",
        variant: "destructive"
      });
    }
  };
  
  // Delete a project from history
  const handleDeleteProject = (id: string) => {
    if (confirm("Sei sicuro di voler eliminare questo progetto?")) {
      const success = deleteSavedProject(id);
      
      if (success) {
        setHistory(prev => prev.filter(p => p.id !== id));
        
        toast({
          title: "Progetto eliminato",
          description: "Il progetto è stato eliminato con successo",
          variant: "default"
        });
      } else {
        toast({
          title: "Errore",
          description: "Impossibile eliminare il progetto",
          variant: "destructive"
        });
      }
    }
  };
  
  // Format date for display
  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return date.toLocaleString('it-IT', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch (e) {
      return dateString;
    }
  };

  return (
    <div className="ios-fade-in pb-20">
      {history.length === 0 ? (
        <div className="ios-card mx-4 p-6">
          <div className="text-center py-10 text-gray-500">
            <Folder className="h-16 w-16 mx-auto mb-3 text-gray-300" />
            <p className="text-gray-500">{t("history.noProjects")}</p>
          </div>
        </div>
      ) : (
        <div className="ios-list">
          {history.map((item) => (
            <IOSCard key={item.id} className="mb-4 mx-4 overflow-hidden">
              <div className="p-4">
                <h3 className="text-base font-semibold mb-2 text-gray-900">
                  {item.name}
                </h3>
                
                <div className="mb-3 space-y-1.5">
                  {item.client && (
                    <div className="flex items-center text-sm text-gray-500">
                      <User className="h-4 w-4 mr-2 text-gray-400" />
                      <span>{item.client}</span>
                    </div>
                  )}
                  
                  {item.date && (
                    <div className="flex items-center text-sm text-gray-500">
                      <Calendar className="h-4 w-4 mr-2 text-gray-400" />
                      <span>{item.date}</span>
                    </div>
                  )}
                  
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock className="h-4 w-4 mr-2 text-gray-400" />
                    <span>{formatDate(item.savedAt)}</span>
                  </div>
                </div>
                
                <div className="flex justify-between items-center border-t border-gray-100 pt-3">
                  <div className="flex gap-3">
                    {item.totalArea !== undefined && (
                      <div className="flex items-center text-sm">
                        <Maximize2 className="h-4 w-4 mr-1 text-primary" />
                        <span>{formatNumber(item.totalArea, "m²")}</span>
                      </div>
                    )}
                    
                    {item.totalCost !== undefined && (
                      <div className="flex items-center text-sm">
                        <CircleDollarSign className="h-4 w-4 mr-1 text-primary" />
                        <span>{formatCurrency(item.totalCost)}</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleLoadProject(item.id)}
                      className="flex items-center p-2 bg-primary/10 rounded-full text-primary"
                      aria-label="Carica progetto"
                    >
                      <ArrowRight className="h-5 w-5" />
                    </button>
                    
                    <button
                      onClick={() => handleDeleteProject(item.id)}
                      className="flex items-center p-2 bg-red-50 rounded-full text-red-500"
                      aria-label="Elimina progetto"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </div>
            </IOSCard>
          ))}
        </div>
      )}
      
      <footer className="text-center text-xs text-gray-400 py-6">
        {t("footer.copyright")}
      </footer>
    </div>
  );
}
