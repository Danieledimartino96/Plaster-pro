import { AlertCircle, ArrowLeft } from "lucide-react";
import { useTranslation } from "@/lib/i18n";
import { useLocation } from "wouter";
import { IOSCard, IOSButton } from "@/components/IOSNavigation";

export default function NotFound() {
  const { t } = useTranslation();
  const [_, navigate] = useLocation();
  
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gray-50 ios-fade-in">
      <IOSCard className="w-full max-w-md mx-4">
        <div className="p-6">
          <div className="flex flex-col items-center text-center mb-6">
            <div className="bg-red-50 rounded-full p-4 mb-4">
              <AlertCircle className="h-10 w-10 text-red-500" />
            </div>
            <h1 className="text-xl font-semibold text-gray-900 mb-2">
              Pagina non trovata
            </h1>
            <p className="text-gray-500 text-sm">
              La pagina che stai cercando non esiste o è stata spostata.
            </p>
          </div>
          
          <IOSButton onClick={() => navigate("/")} variant="primary">
            <div className="flex items-center justify-center space-x-2">
              <ArrowLeft className="w-5 h-5" />
              <span>{t("back_to_home")}</span>
            </div>
          </IOSButton>
        </div>
      </IOSCard>
    </div>
  );
}
