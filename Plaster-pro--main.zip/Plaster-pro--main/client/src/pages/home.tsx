import ProjectDetails from "@/components/ProjectDetails";
import MaterialCalculator from "@/components/MaterialCalculator";
import RoomList from "@/components/RoomList";
import ProjectSummary from "@/components/ProjectSummary";
import { useTranslation } from "@/lib/i18n.tsx";
import { IOSCard, IOSButton } from "@/components/IOSNavigation";
import { Plus, Download, Trash2 } from "lucide-react";
import { useProject } from "@/hooks/useProject";

export default function Home() {
  const { t } = useTranslation();
  const { newProject, exportPdf } = useProject();
  
  return (
    <div className="ios-fade-in pb-20">
      {/* Sezione Progetto con stile iOS */}
      <div className="mb-6">
        <h2 className="ios-section-header">{t("project_details")}</h2>
        <IOSCard>
          <div className="p-4">
            <ProjectDetails />
          </div>
        </IOSCard>
      </div>
      
      {/* Sezione Calcolo Materiale con stile iOS */}
      <div className="mb-6">
        <h2 className="ios-section-header">{t("material_calculator")}</h2>
        <IOSCard>
          <div className="p-4">
            <MaterialCalculator />
          </div>
        </IOSCard>
      </div>
      
      {/* Elenco Stanze con stile iOS */}
      <div className="mb-6">
        <div className="flex justify-between items-center">
          <h2 className="ios-section-header">{t("rooms")}</h2>
        </div>
        <div className="ios-fade-in">
          <RoomList />
        </div>
      </div>
      
      {/* Riepilogo Progetto con stile iOS */}
      <div className="mb-6">
        <h2 className="ios-section-header">{t("project_summary")}</h2>
        <IOSCard>
          <div className="p-4">
            <ProjectSummary />
          </div>
        </IOSCard>
      </div>
      
      {/* Gruppo di azioni in stile iOS */}
      <div className="flex flex-col space-y-3 px-4 mb-6">
        <IOSButton onClick={exportPdf} variant="primary">
          <div className="flex items-center justify-center space-x-2">
            <Download className="w-5 h-5" />
            <span>{t("export_pdf")}</span>
          </div>
        </IOSButton>
        
        <IOSButton onClick={newProject} variant="danger">
          <div className="flex items-center justify-center space-x-2">
            <Trash2 className="w-5 h-5" />
            <span>{t("new_project")}</span>
          </div>
        </IOSButton>
      </div>
      
      <footer className="text-center text-xs text-gray-400 py-6">
        {t("footer.copyright")}
      </footer>
    </div>
  );
}
