import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { Room, Measurement, ProjectData } from "@shared/schema";
import { v4 as uuidv4 } from "uuid";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Generate a unique ID
export function generateId(): string {
  return uuidv4();
}

// Calculate the area of a wall or ceiling
export function calculateArea(measurement: Measurement): number {
  const { length, height, deductions } = measurement;
  const area = length * height - deductions;
  return Math.max(0, parseFloat(area.toFixed(2)));
}

// Calculate total wall area, ceiling area, and total area for a room
export function calculateRoomAreas(room: Room): {
  wallArea: number;
  ceilingArea: number;
  totalArea: number;
} {
  let wallArea = 0;
  let ceilingArea = 0;

  room.measurements.forEach((measurement) => {
    const area = calculateArea(measurement);
    if (measurement.isCeiling) {
      ceilingArea += area;
    } else {
      wallArea += area;
    }
  });

  wallArea = parseFloat(wallArea.toFixed(2));
  ceilingArea = parseFloat(ceilingArea.toFixed(2));
  const totalArea = parseFloat((wallArea + ceilingArea).toFixed(2));

  return { wallArea, ceilingArea, totalArea };
}

// Calculate materials needed for a specific area
export function calculateMaterials(
  area: number,
  thickness: number,
  materialYield: number,
  materialPrice: number
): { bags: number; cost: number } {
  // Apply thickness correction factor (e.g., 15mm is 1.0, 10mm is 0.67, 20mm is 1.33)
  const thicknessCorrection = thickness / 15;
  
  // Calculate bags needed for the area with thickness correction
  const bagsNeeded = Math.ceil((area * thicknessCorrection) / materialYield);
  
  // Calculate cost
  const cost = parseFloat((bagsNeeded * materialPrice).toFixed(2));

  return { bags: bagsNeeded, cost };
}

// Calculate all metrics for a project
export function calculateProjectTotals(project: ProjectData): {
  rooms: Room[];
  totalArea: number;
  totalBags: number;
  totalCost: number;
} {
  let totalArea = 0;
  let totalBags = 0;
  let totalCost = 0;

  const updatedRooms = project.rooms.map((room) => {
    // Calculate areas for the room
    const { wallArea, ceilingArea, totalArea: roomTotalArea } = calculateRoomAreas(room);
    
    // Calculate materials needed for this room
    const { bags, cost } = calculateMaterials(
      roomTotalArea,
      project.materials.thickness,
      project.materials.yield,
      project.materials.price
    );

    // Update totals
    totalArea += roomTotalArea;
    totalBags += bags;
    totalCost += cost;

    // Return updated room with calculated values
    return {
      ...room,
      wallArea,
      ceilingArea,
      totalArea: roomTotalArea,
      materials: { bags, cost }
    };
  });

  return {
    rooms: updatedRooms,
    totalArea: parseFloat(totalArea.toFixed(2)),
    totalBags,
    totalCost: parseFloat(totalCost.toFixed(2))
  };
}

// Create a new measurement
export function createMeasurement(defaults?: Partial<Measurement>): Measurement {
  return {
    id: generateId(),
    length: defaults?.length || 0,
    height: defaults?.height || 0,
    deductions: defaults?.deductions || 0,
    isCeiling: defaults?.isCeiling || false,
    name: defaults?.name || "",
    area: defaults?.area || 0
  };
}

// Create a new room
export function createRoom(defaults?: Partial<Room>): Room {
  return {
    id: generateId(),
    name: defaults?.name || "Nuova Stanza",
    measurements: defaults?.measurements || [createMeasurement()],
    wallArea: defaults?.wallArea || 0,
    ceilingArea: defaults?.ceilingArea || 0,
    totalArea: defaults?.totalArea || 0,
    materials: defaults?.materials || { bags: 0, cost: 0 }
  };
}

// Create a default new project
export function createNewProject(): ProjectData {
  return {
    name: "Nuovo Progetto",
    client: "",
    address: "",
    date: new Date().toISOString().split('T')[0],
    materials: {
      type: "standard",
      thickness: 15,
      price: 8.5,
      yield: 1.6
    },
    rooms: [createRoom()],
    totalArea: 0,
    totalBags: 0,
    totalCost: 0
  };
}

// Format number as currency
export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('it-IT', {
    style: 'currency',
    currency: 'EUR'
  }).format(value);
}

// Format number with units
export function formatNumber(value: number, unit: string = "", decimals: number = 2): string {
  return `${value.toFixed(decimals)}${unit ? ' ' + unit : ''}`;
}

// Service worker registration
export function registerSW() {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', async () => {
      try {
        const registration = await navigator.serviceWorker.register('/sw.js');
        
        // Registrazione completata
        console.log('Service Worker registrato con successo:', registration.scope);
        
        // Gestione degli aggiornamenti
        registration.addEventListener('updatefound', () => {
          const newWorker = registration.installing;
          
          if (newWorker) {
            newWorker.addEventListener('statechange', () => {
              if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                // Un nuovo service worker è stato installato, ma non è ancora attivo
                // Mostra un messaggio all'utente per aggiornare la pagina
                if (confirm('Nuova versione disponibile! Vuoi aggiornare l\'app?')) {
                  window.location.reload();
                }
              }
            });
          }
        });
      } catch (error) {
        console.error('Errore durante la registrazione del Service Worker:', error);
      }
    });
    
    // Gestione degli eventi online/offline
    window.addEventListener('online', () => {
      console.log('App tornata online');
      document.dispatchEvent(new CustomEvent('app-online'));
    });
    
    window.addEventListener('offline', () => {
      console.log('App offline');
      document.dispatchEvent(new CustomEvent('app-offline'));
    });
  }
}

// Check if online
export function isOnline(): boolean {
  return navigator.onLine;
}
