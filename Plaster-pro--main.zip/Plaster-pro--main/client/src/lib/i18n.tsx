import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { Language, TranslationMap } from "@/types";

// Default language
const DEFAULT_LANGUAGE: Language = "it";

// Translations map
const translations: TranslationMap = {
  // App title
  "app.title": {
    it: "PLASTER PRO",
    en: "PLASTER PRO",
    es: "PLASTER PRO",
    fr: "PLASTER PRO",
    de: "PLASTER PRO"
  },
  "app.subtitle": {
    it: "Calcolo Professionale di Intonaci",
    en: "Professional Plaster Calculation",
    es: "Cálculo Profesional de Yeso",
    fr: "Calcul Professionnel de Plâtre",
    de: "Professionelle Putzberechnung"
  },
  
  // Toolbar
  "toolbar.newProject": {
    it: "Nuovo Progetto",
    en: "New Project",
    es: "Nuevo Proyecto",
    fr: "Nouveau Projet",
    de: "Neues Projekt"
  },
  "toolbar.saveProject": {
    it: "Salva Progetto",
    en: "Save Project",
    es: "Guardar Proyecto",
    fr: "Sauvegarder Projet",
    de: "Projekt Speichern"
  },
  "toolbar.loadProject": {
    it: "Carica Progetto",
    en: "Load Project",
    es: "Cargar Proyecto",
    fr: "Charger Projet",
    de: "Projekt Laden"
  },
  "toolbar.exportPdf": {
    it: "Esporta PDF",
    en: "Export PDF",
    es: "Exportar PDF",
    fr: "Exporter PDF",
    de: "PDF Exportieren"
  },
  "toolbar.history": {
    it: "Cronologia",
    en: "History",
    es: "Historial",
    fr: "Historique",
    de: "Verlauf"
  },
  
  // Project details
  "project.details": {
    it: "Dettagli Progetto",
    en: "Project Details",
    es: "Detalles del Proyecto",
    fr: "Détails du Projet",
    de: "Projektdetails"
  },
  "project.name": {
    it: "Nome Progetto",
    en: "Project Name",
    es: "Nombre del Proyecto",
    fr: "Nom du Projet",
    de: "Projektname"
  },
  "project.client": {
    it: "Nome Cliente",
    en: "Client Name",
    es: "Nombre del Cliente",
    fr: "Nom du Client",
    de: "Kundenname"
  },
  "project.address": {
    it: "Indirizzo",
    en: "Address",
    es: "Dirección",
    fr: "Adresse",
    de: "Adresse"
  },
  "project.date": {
    it: "Data",
    en: "Date",
    es: "Fecha",
    fr: "Date",
    de: "Datum"
  },
  
  // Material calculator
  "materials.calculator": {
    it: "Calcolo Materiali",
    en: "Materials Calculation",
    es: "Cálculo de Materiales",
    fr: "Calcul des Matériaux",
    de: "Materialberechnung"
  },
  "materials.type": {
    it: "Tipo di Intonaco",
    en: "Plaster Type",
    es: "Tipo de Yeso",
    fr: "Type de Plâtre",
    de: "Putztyp"
  },
  "materials.thickness": {
    it: "Spessore Intonaco (mm)",
    en: "Plaster Thickness (mm)",
    es: "Espesor del Yeso (mm)",
    fr: "Épaisseur du Plâtre (mm)",
    de: "Putzdicke (mm)"
  },
  "materials.price": {
    it: "Prezzo Materiale (€/sacco)",
    en: "Material Price (€/bag)",
    es: "Precio del Material (€/bolsa)",
    fr: "Prix du Matériel (€/sac)",
    de: "Materialpreis (€/Sack)"
  },
  "materials.yield": {
    it: "Rendimento (m²/sacco)",
    en: "Yield (m²/bag)",
    es: "Rendimiento (m²/bolsa)",
    fr: "Rendement (m²/sac)",
    de: "Ausbeute (m²/Sack)"
  },
  
  // Rooms
  "room.new": {
    it: "Nuova Stanza",
    en: "New Room",
    es: "Nueva Habitación",
    fr: "Nouvelle Pièce",
    de: "Neuer Raum"
  },
  "room.measurements": {
    it: "Misurazioni Pareti",
    en: "Wall Measurements",
    es: "Medidas de Paredes",
    fr: "Mesures des Murs",
    de: "Wandmaße"
  },
  "room.wall": {
    it: "Parete",
    en: "Wall",
    es: "Pared",
    fr: "Mur",
    de: "Wand"
  },
  "room.ceiling": {
    it: "Soffitto",
    en: "Ceiling",
    es: "Techo",
    fr: "Plafond",
    de: "Decke"
  },
  "room.length": {
    it: "Lunghezza",
    en: "Length",
    es: "Longitud",
    fr: "Longueur",
    de: "Länge"
  },
  "room.height": {
    it: "Altezza",
    en: "Height",
    es: "Altura",
    fr: "Hauteur",
    de: "Höhe"
  },
  "room.deductions": {
    it: "Detrazioni",
    en: "Deductions",
    es: "Deducciones",
    fr: "Déductions",
    de: "Abzüge"
  },
  "room.area": {
    it: "Superficie",
    en: "Area",
    es: "Área",
    fr: "Surface",
    de: "Fläche"
  },
  "room.addMeasurement": {
    it: "Aggiungi Misurazione",
    en: "Add Measurement",
    es: "Añadir Medida",
    fr: "Ajouter Mesure",
    de: "Messung Hinzufügen"
  },
  "room.addRoom": {
    it: "Aggiungi Stanza",
    en: "Add Room",
    es: "Añadir Habitación",
    fr: "Ajouter Pièce",
    de: "Raum Hinzufügen"
  },
  
  // Summary
  "summary.title": {
    it: "Riepilogo Progetto",
    en: "Project Summary",
    es: "Resumen del Proyecto",
    fr: "Résumé du Projet",
    de: "Projektübersicht"
  },
  "summary.totalWalls": {
    it: "Superficie totale pareti",
    en: "Total wall area",
    es: "Área total de paredes",
    fr: "Surface totale des murs",
    de: "Gesamtwandfläche"
  },
  "summary.totalCeilings": {
    it: "Superficie totale soffitti",
    en: "Total ceiling area",
    es: "Área total de techos",
    fr: "Surface totale des plafonds",
    de: "Gesamtdeckenfläche"
  },
  "summary.totalArea": {
    it: "Superficie totale",
    en: "Total area",
    es: "Área total",
    fr: "Surface totale",
    de: "Gesamtfläche"
  },
  "summary.bagsNeeded": {
    it: "Sacchi necessari",
    en: "Bags needed",
    es: "Bolsas necesarias",
    fr: "Sacs nécessaires",
    de: "Benötigte Säcke"
  },
  "summary.totalCost": {
    it: "Costo totale",
    en: "Total cost",
    es: "Costo total",
    fr: "Coût total",
    de: "Gesamtkosten"
  },
  
  // History page
  "history.title": {
    it: "Cronologia Progetti",
    en: "Project History",
    es: "Historial de Proyectos",
    fr: "Historique des Projets",
    de: "Projektverlauf"
  },
  "history.noProjects": {
    it: "Nessun progetto salvato",
    en: "No saved projects",
    es: "No hay proyectos guardados",
    fr: "Aucun projet sauvegardé",
    de: "Keine gespeicherten Projekte"
  },
  "history.load": {
    it: "Carica",
    en: "Load",
    es: "Cargar",
    fr: "Charger",
    de: "Laden"
  },
  "history.delete": {
    it: "Elimina",
    en: "Delete",
    es: "Eliminar",
    fr: "Supprimer",
    de: "Löschen"
  },
  
  // Notifications
  "notify.projectSaved": {
    it: "Progetto salvato con successo",
    en: "Project saved successfully",
    es: "Proyecto guardado exitosamente",
    fr: "Projet sauvegardé avec succès",
    de: "Projekt erfolgreich gespeichert"
  },
  "notify.projectLoaded": {
    it: "Progetto caricato con successo",
    en: "Project loaded successfully",
    es: "Proyecto cargado exitosamente",
    fr: "Projet chargé avec succès",
    de: "Projekt erfolgreich geladen"
  },
  "notify.projectDeleted": {
    it: "Progetto eliminato con successo",
    en: "Project deleted successfully",
    es: "Proyecto eliminado exitosamente",
    fr: "Projet supprimé avec succès",
    de: "Projekt erfolgreich gelöscht"
  },
  "notify.exportComplete": {
    it: "PDF esportato con successo",
    en: "PDF exported successfully",
    es: "PDF exportado exitosamente",
    fr: "PDF exporté avec succès",
    de: "PDF erfolgreich exportiert"
  },
  "notify.offlineMode": {
    it: "Modalità offline attiva",
    en: "Offline mode active",
    es: "Modo offline activo",
    fr: "Mode hors ligne actif",
    de: "Offline-Modus aktiv"
  },
  
  // Misc
  "footer.copyright": {
    it: "PLASTER PRO © 2023 - Tutti i diritti riservati",
    en: "PLASTER PRO © 2023 - All rights reserved",
    es: "PLASTER PRO © 2023 - Todos los derechos reservados",
    fr: "PLASTER PRO © 2023 - Tous droits réservés",
    de: "PLASTER PRO © 2023 - Alle Rechte vorbehalten"
  },
  "actions.share": {
    it: "Condividi su WhatsApp",
    en: "Share on WhatsApp",
    es: "Compartir en WhatsApp",
    fr: "Partager sur WhatsApp",
    de: "Auf WhatsApp teilen"
  }
};

// Get translation
export function getTranslation(key: string, lang: Language = DEFAULT_LANGUAGE): string {
  if (!translations[key]) {
    console.warn(`Translation key not found: ${key}`);
    return key;
  }
  
  return translations[key][lang] || translations[key][DEFAULT_LANGUAGE];
}

// I18n context
interface I18nContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const I18nContext = createContext<I18nContextType>({
  language: DEFAULT_LANGUAGE,
  setLanguage: () => {},
  t: (key: string) => key
});

// Hook to use translations
export function useTranslation() {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error("useTranslation must be used within an I18nProvider");
  }
  return context;
}

// I18n provider component
interface I18nProviderProps {
  children: ReactNode;
}

export function I18nProvider({ children }: I18nProviderProps) {
  // Try to get language from localStorage or default to Italian
  const [language, setLanguageState] = useState<Language>(() => {
    const savedLang = localStorage.getItem("language") as Language;
    return savedLang || DEFAULT_LANGUAGE;
  });

  // Set language and save to localStorage
  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem("language", lang);
  };

  // Translation function
  const t = (key: string) => getTranslation(key, language);

  return (
    <I18nContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </I18nContext.Provider>
  );
}
