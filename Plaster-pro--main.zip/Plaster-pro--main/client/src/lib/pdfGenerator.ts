import { ProjectData, Room, Measurement } from "@shared/schema";
import { formatCurrency, formatNumber, calculateArea } from "./utils";
import { getTranslation } from "./i18n";

// We're using the global jsPDF from CDN
declare global {
  interface Window {
    jspdf: any;
  }
}

export function generatePDF(project: ProjectData): void {
  // Access the jsPDF library from the global scope
  const { jsPDF } = window.jspdf;
  
  if (!jsPDF) {
    console.error("jsPDF library not loaded");
    return;
  }

  // Create a new PDF document
  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4"
  });

  const t = (key: string) => getTranslation(key, "it"); // We're using Italian as default

  // Add header with logo
  addHeader(doc, project);

  // Add project details
  addProjectDetails(doc, project);

  // Add materials section
  addMaterialsSection(doc, project);

  // Add rooms sections
  let yPos = 100;
  project.rooms.forEach((room, index) => {
    // Check if we need a new page
    if (yPos > 240) {
      doc.addPage();
      yPos = 20;
    }
    
    addRoomSection(doc, room, yPos, index);
    yPos += calculateRoomSectionHeight(room);
  });

  // Add summary section
  if (yPos > 220) {
    doc.addPage();
    yPos = 20;
  }
  
  addSummarySection(doc, project, yPos);

  // Add footer
  addFooter(doc);

  // Save the PDF
  doc.save(`${project.name || "Progetto"}_${new Date().toISOString().slice(0, 10)}.pdf`);
}

function addHeader(doc: any, project: ProjectData): void {
  // Add gradient header bar
  doc.setFillColor(0, 113, 227); // Apple blue
  doc.rect(0, 0, 210, 4, "F");

  // Add title
  doc.setFont("helvetica", "bold");
  doc.setFontSize(24);
  doc.setTextColor(0, 113, 227); // Apple blue
  doc.text("PLASTER PRO", 105, 15, { align: "center" });

  // Add subtitle
  doc.setFontSize(12);
  doc.setTextColor(100, 100, 100);
  doc.setFont("helvetica", "normal");
  doc.text("Calcolo Professionale di Intonaci", 105, 22, { align: "center" });

  // Add date
  doc.setFontSize(10);
  doc.setTextColor(100, 100, 100);
  const date = project.date 
    ? new Date(project.date).toLocaleDateString('it-IT') 
    : new Date().toLocaleDateString('it-IT');
  doc.text(`Data: ${date}`, 185, 30, { align: "right" });
}

function addProjectDetails(doc: any, project: ProjectData): void {
  doc.setFillColor(240, 240, 240);
  doc.rect(10, 35, 190, 30, "F");
  
  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(50, 50, 50);
  doc.text("Dettagli Progetto", 15, 45);
  
  doc.setFontSize(11);
  doc.setFont("helvetica", "normal");
  
  // Project name
  doc.text(`Nome progetto: ${project.name}`, 15, 53);
  
  // Client
  if (project.client) {
    doc.text(`Cliente: ${project.client}`, 15, 60);
  }
  
  // Address
  if (project.address) {
    doc.text(`Indirizzo: ${project.address}`, 110, 53);
  }
}

function addMaterialsSection(doc: any, project: ProjectData): void {
  doc.setFillColor(230, 230, 230);
  doc.rect(10, 70, 190, 25, "F");
  
  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(50, 50, 50);
  doc.text("Dettagli Materiali", 15, 80);
  
  doc.setFontSize(11);
  doc.setFont("helvetica", "normal");
  
  // Material type
  const materialTypeMap: Record<string, string> = {
    standard: "Intonaco Standard",
    premixed: "Intonaco Premiscelato",
    lime: "Intonaco di Calce",
    cement: "Intonaco Cementizio",
    gypsum: "Intonaco di Gesso"
  };
  
  const materialType = materialTypeMap[project.materials.type] || project.materials.type;
  
  doc.text(`Tipo intonaco: ${materialType}`, 15, 88);
  doc.text(`Spessore: ${project.materials.thickness} mm`, 110, 88);
  doc.text(`Prezzo: ${formatCurrency(project.materials.price)} / sacco`, 15, 95);
  doc.text(`Rendimento: ${project.materials.yield} m²/sacco`, 110, 95);
}

function calculateRoomSectionHeight(room: Room): number {
  // Base height for room header and summary
  let height = 40;
  
  // Add height for each measurement (10mm per measurement)
  height += room.measurements.length * 10;
  
  return height;
}

function addRoomSection(doc: any, room: Room, yPos: number, index: number): void {
  // Room header
  doc.setFillColor(0, 113, 227, 0.1); // Light blue background
  doc.rect(10, yPos, 190, 10, "F");
  
  doc.setFontSize(12);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(0, 113, 227);
  doc.text(`Stanza ${index + 1}: ${room.name}`, 15, yPos + 7);
  
  // Measurements table header
  doc.setFontSize(10);
  doc.setTextColor(80, 80, 80);
  yPos += 15;
  doc.text("Misurazione", 15, yPos);
  doc.text("Lunghezza (m)", 60, yPos);
  doc.text("Altezza (m)", 95, yPos);
  doc.text("Detrazioni (m²)", 130, yPos);
  doc.text("Area (m²)", 175, yPos);
  
  // Measurements
  doc.setFont("helvetica", "normal");
  yPos += 5;
  
  room.measurements.forEach((measurement, i) => {
    yPos += 5;
    doc.text(measurement.isCeiling ? "Soffitto" : `Parete ${i + 1}`, 15, yPos);
    doc.text(measurement.length.toString(), 70, yPos, { align: "center" });
    doc.text(measurement.height.toString(), 105, yPos, { align: "center" });
    doc.text(measurement.deductions.toString(), 140, yPos, { align: "center" });
    
    const area = calculateArea(measurement);
    doc.text(area.toString(), 175, yPos, { align: "center" });
  });
  
  // Room summary
  yPos += 10;
  doc.setFillColor(240, 240, 240);
  doc.rect(10, yPos, 190, 20, "F");
  
  doc.setFont("helvetica", "bold");
  doc.text("Riepilogo stanza:", 15, yPos + 7);
  
  doc.setFont("helvetica", "normal");
  doc.text(`Superficie pareti: ${formatNumber(room.wallArea || 0, "m²")}`, 15, yPos + 15);
  doc.text(`Superficie soffitto: ${formatNumber(room.ceilingArea || 0, "m²")}`, 80, yPos + 15);
  doc.text(`Totale: ${formatNumber(room.totalArea || 0, "m²")}`, 150, yPos + 15);
}

function addSummarySection(doc: any, project: ProjectData, yPos: number): void {
  doc.setFillColor(0, 113, 227, 0.2); // Light blue background
  doc.rect(10, yPos, 190, 40, "F");
  
  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(0, 70, 140);
  doc.text("Riepilogo Progetto", 105, yPos + 10, { align: "center" });
  
  doc.setFontSize(12);
  doc.setTextColor(50, 50, 50);
  
  // Project totals
  const totalRooms = project.rooms.length;
  const totalWallArea = project.rooms.reduce((sum, room) => sum + (room.wallArea || 0), 0);
  const totalCeilingArea = project.rooms.reduce((sum, room) => sum + (room.ceilingArea || 0), 0);
  
  doc.text(`Numero di stanze: ${totalRooms}`, 15, yPos + 20);
  doc.text(`Superficie totale pareti: ${formatNumber(totalWallArea, "m²")}`, 15, yPos + 28);
  doc.text(`Superficie totale soffitti: ${formatNumber(totalCeilingArea, "m²")}`, 115, yPos + 28);
  
  // Materials summary
  doc.setTextColor(0, 70, 140);
  doc.text(`Superficie totale: ${formatNumber(project.totalArea || 0, "m²")}`, 15, yPos + 36);
  doc.text(`Sacchi necessari: ${project.totalBags || 0}`, 115, yPos + 36);
  
  // Cost
  doc.setFontSize(14);
  doc.text(`Costo totale: ${formatCurrency(project.totalCost || 0)}`, 180, yPos + 36, { align: "right" });
}

function addFooter(doc: any): void {
  const pageCount = doc.internal.getNumberOfPages();
  doc.setFontSize(10);
  doc.setTextColor(150, 150, 150);
  
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    
    // Add footer text
    doc.text("PLASTER PRO | Calcolo Professionale di Intonaci", 105, 285, { align: "center" });
    doc.text(`Pagina ${i} di ${pageCount}`, 190, 285, { align: "right" });
  }
}
