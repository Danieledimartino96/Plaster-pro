import { ProjectData, projectDataSchema } from "@shared/schema";
import { LocalStorageProject, HistoryItem } from "@/types";
import { generateId } from "./utils";

// Storage keys
const CURRENT_PROJECT_KEY = "plaster_pro_current_project";
const PROJECTS_KEY = "plaster_pro_saved_projects";

// Save current project to localStorage
export function saveCurrentProject(project: ProjectData): void {
  try {
    localStorage.setItem(CURRENT_PROJECT_KEY, JSON.stringify(project));
  } catch (error) {
    console.error("Failed to save current project to localStorage:", error);
  }
}

// Load current project from localStorage
export function loadCurrentProject(): ProjectData | null {
  try {
    const savedProject = localStorage.getItem(CURRENT_PROJECT_KEY);
    if (!savedProject) return null;
    
    const parsed = JSON.parse(savedProject);
    const result = projectDataSchema.safeParse(parsed);
    
    if (result.success) {
      return result.data;
    } else {
      console.error("Invalid project data in localStorage:", result.error);
      return null;
    }
  } catch (error) {
    console.error("Failed to load current project from localStorage:", error);
    return null;
  }
}

// Save project to history
export function saveProjectToHistory(project: ProjectData): string {
  try {
    const projects = getSavedProjects();
    const projectId = generateId();
    
    const savedProject: LocalStorageProject = {
      ...project,
      id: projectId,
      savedAt: new Date().toISOString()
    };
    
    projects.push(savedProject);
    localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects));
    
    return projectId;
  } catch (error) {
    console.error("Failed to save project to history:", error);
    return "";
  }
}

// Get all saved projects
export function getSavedProjects(): LocalStorageProject[] {
  try {
    const savedProjects = localStorage.getItem(PROJECTS_KEY);
    if (!savedProjects) return [];
    
    return JSON.parse(savedProjects) as LocalStorageProject[];
  } catch (error) {
    console.error("Failed to load saved projects from localStorage:", error);
    return [];
  }
}

// Get saved project by ID
export function getSavedProjectById(id: string): ProjectData | null {
  try {
    const projects = getSavedProjects();
    const project = projects.find(p => p.id === id);
    
    if (!project) return null;
    
    return project;
  } catch (error) {
    console.error("Failed to load saved project:", error);
    return null;
  }
}

// Delete saved project
export function deleteSavedProject(id: string): boolean {
  try {
    const projects = getSavedProjects();
    const updatedProjects = projects.filter(p => p.id !== id);
    
    localStorage.setItem(PROJECTS_KEY, JSON.stringify(updatedProjects));
    return true;
  } catch (error) {
    console.error("Failed to delete saved project:", error);
    return false;
  }
}

// Get project history
export function getProjectHistory(): HistoryItem[] {
  try {
    const projects = getSavedProjects();
    
    return projects.map(project => ({
      id: project.id,
      name: project.name,
      client: project.client,
      date: project.date,
      savedAt: project.savedAt,
      totalArea: project.totalArea,
      totalCost: project.totalCost
    })).sort((a, b) => {
      // Sort by date saved, newest first
      return new Date(b.savedAt).getTime() - new Date(a.savedAt).getTime();
    });
  } catch (error) {
    console.error("Failed to get project history:", error);
    return [];
  }
}

// Init IndexedDB for larger storage needs
export async function initIndexedDB(): Promise<IDBDatabase | null> {
  return new Promise((resolve) => {
    if (!window.indexedDB) {
      console.warn("Your browser doesn't support IndexedDB");
      resolve(null);
      return;
    }
    
    const request = indexedDB.open("PlasterProDB", 1);
    
    request.onerror = (event) => {
      console.error("IndexedDB error:", event);
      resolve(null);
    };
    
    request.onsuccess = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      resolve(db);
    };
    
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      
      // Create object stores
      if (!db.objectStoreNames.contains("projects")) {
        db.createObjectStore("projects", { keyPath: "id" });
      }
    };
  });
}
