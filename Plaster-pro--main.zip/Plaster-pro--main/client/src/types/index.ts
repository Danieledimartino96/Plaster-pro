import { ProjectData, Room, Measurement } from "@shared/schema";

export interface ThemeContextType {
  theme: "light" | "dark" | "system";
  setTheme: (theme: "light" | "dark" | "system") => void;
  resolvedTheme: "light" | "dark";
}

export interface ProjectContextType {
  project: ProjectData;
  setProject: (project: ProjectData) => void;
  updateProject: (updates: Partial<ProjectData>) => void;
  addRoom: () => void;
  deleteRoom: (roomId: string) => void;
  duplicateRoom: (roomId: string) => void;
  updateRoom: (roomId: string, updates: Partial<Room>) => void;
  addMeasurement: (roomId: string) => void;
  deleteMeasurement: (roomId: string, measurementId: string) => void;
  updateMeasurement: (roomId: string, measurementId: string, updates: Partial<Measurement>) => void;
  toggleCeiling: (roomId: string, measurementId: string) => void;
  calculateProject: () => void;
  saveProject: () => Promise<boolean>;
  loadProject: (id: number) => Promise<boolean>;
  newProject: () => void;
  exportPdf: () => void;
  isOnline: boolean;
}

export interface PlasterType {
  id: string;
  name: string;
  defaultYield: number;
  defaultPrice: number;
}

export type Language = "it" | "en" | "es" | "fr" | "de";

export interface TranslationMap {
  [key: string]: {
    [lang in Language]: string;
  };
}

export interface LocalStorageProject extends ProjectData {
  id: string;
  savedAt: string;
}

export interface HistoryItem {
  id: string;
  name: string;
  client: string;
  date: string;
  savedAt: string;
  totalArea?: number;
  totalCost?: number;
}
