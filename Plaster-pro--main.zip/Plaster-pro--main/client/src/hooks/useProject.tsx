import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { ProjectContextType } from "@/types";
import { ProjectData, Room, Measurement, projectDataSchema } from "@shared/schema";
import { 
  createNewProject, 
  createRoom, 
  createMeasurement, 
  calculateProjectTotals,
  calculateArea
} from "@/lib/utils";
import { 
  saveCurrentProject, 
  loadCurrentProject, 
  saveProjectToHistory,
  getSavedProjectById
} from "@/lib/storage";
import { generatePDF } from "@/lib/pdfGenerator";
import { useToast } from "@/hooks/use-toast";

// Create a context
const ProjectContext = createContext<ProjectContextType>({
  project: createNewProject(),
  setProject: () => {},
  updateProject: () => {},
  addRoom: () => {},
  deleteRoom: () => {},
  duplicateRoom: () => {},
  updateRoom: () => {},
  addMeasurement: () => {},
  deleteMeasurement: () => {},
  updateMeasurement: () => {},
  toggleCeiling: () => {},
  calculateProject: () => {},
  saveProject: async () => false,
  loadProject: async () => false,
  newProject: () => {},
  exportPdf: () => {},
  isOnline: true
});

// Hook to use project context
export function useProject() {
  const context = useContext(ProjectContext);
  if (!context) {
    throw new Error("useProject must be used within a ProjectProvider");
  }
  return context;
}

// Provider component
interface ProjectProviderProps {
  children: ReactNode;
}

export function ProjectProvider({ children }: ProjectProviderProps) {
  // State
  const [project, setProjectState] = useState<ProjectData>(() => {
    // Try to load from localStorage on initial render
    const savedProject = loadCurrentProject();
    return savedProject || createNewProject();
  });
  
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  
  const { toast } = useToast();

  // Update online status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => {
      setIsOnline(false);
      toast({
        title: "Modalità offline attiva",
        description: "I tuoi dati verranno salvati localmente",
        variant: "default"
      });
    };

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, [toast]);

  // Auto-save project to localStorage when it changes
  useEffect(() => {
    saveCurrentProject(project);
  }, [project]);

  // Set project
  const setProject = (newProject: ProjectData) => {
    const result = projectDataSchema.safeParse(newProject);
    if (result.success) {
      setProjectState(result.data);
    } else {
      console.error("Invalid project data", result.error);
    }
  };

  // Update project properties
  const updateProject = (updates: Partial<ProjectData>) => {
    setProjectState(prev => ({ ...prev, ...updates }));
  };

  // Add a new room
  const addRoom = () => {
    setProjectState(prev => ({
      ...prev,
      rooms: [...prev.rooms, createRoom()]
    }));
  };

  // Delete a room
  const deleteRoom = (roomId: string) => {
    setProjectState(prev => ({
      ...prev,
      rooms: prev.rooms.filter(room => room.id !== roomId)
    }));
  };

  // Duplicate a room
  const duplicateRoom = (roomId: string) => {
    const roomToDuplicate = project.rooms.find(room => room.id === roomId);
    if (!roomToDuplicate) return;

    const newRoom = createRoom({
      ...roomToDuplicate,
      id: undefined,
      name: `${roomToDuplicate.name} (copia)`
    });

    setProjectState(prev => ({
      ...prev,
      rooms: [...prev.rooms, newRoom]
    }));
  };

  // Update a room
  const updateRoom = (roomId: string, updates: Partial<Room>) => {
    setProjectState(prev => ({
      ...prev,
      rooms: prev.rooms.map(room => 
        room.id === roomId ? { ...room, ...updates } : room
      )
    }));
  };

  // Add a measurement to a room
  const addMeasurement = (roomId: string) => {
    setProjectState(prev => ({
      ...prev,
      rooms: prev.rooms.map(room => {
        if (room.id === roomId) {
          return {
            ...room,
            measurements: [...room.measurements, createMeasurement()]
          };
        }
        return room;
      })
    }));
  };

  // Delete a measurement from a room
  const deleteMeasurement = (roomId: string, measurementId: string) => {
    setProjectState(prev => ({
      ...prev,
      rooms: prev.rooms.map(room => {
        if (room.id === roomId) {
          return {
            ...room,
            measurements: room.measurements.filter(m => m.id !== measurementId)
          };
        }
        return room;
      })
    }));
  };

  // Update a measurement
  const updateMeasurement = (
    roomId: string,
    measurementId: string,
    updates: Partial<Measurement>
  ) => {
    setProjectState(prev => ({
      ...prev,
      rooms: prev.rooms.map(room => {
        if (room.id === roomId) {
          return {
            ...room,
            measurements: room.measurements.map(m => {
              if (m.id === measurementId) {
                const updated = { ...m, ...updates };
                // Recalculate area if dimensions changed
                if (
                  'length' in updates || 
                  'height' in updates || 
                  'deductions' in updates
                ) {
                  updated.area = calculateArea(updated);
                }
                return updated;
              }
              return m;
            })
          };
        }
        return room;
      })
    }));
  };

  // Toggle ceiling status for a measurement
  const toggleCeiling = (roomId: string, measurementId: string) => {
    setProjectState(prev => ({
      ...prev,
      rooms: prev.rooms.map(room => {
        if (room.id === roomId) {
          return {
            ...room,
            measurements: room.measurements.map(m => {
              if (m.id === measurementId) {
                return { ...m, isCeiling: !m.isCeiling };
              }
              return m;
            })
          };
        }
        return room;
      })
    }));
  };

  // Calculate all metrics for the project
  const calculateProject = () => {
    const { rooms, totalArea, totalBags, totalCost } = calculateProjectTotals(project);
    
    setProjectState(prev => ({
      ...prev,
      rooms,
      totalArea,
      totalBags,
      totalCost
    }));
  };

  // Save project to history
  const saveProject = async (): Promise<boolean> => {
    try {
      // Calculate before saving to ensure numbers are up to date
      calculateProject();
      
      // Save to history
      const id = saveProjectToHistory(project);
      
      if (id) {
        toast({
          title: "Progetto salvato",
          description: "Il progetto è stato salvato nella cronologia",
          variant: "success"
        });
        return true;
      }
      
      return false;
    } catch (error) {
      console.error("Error saving project:", error);
      
      toast({
        title: "Errore",
        description: "Impossibile salvare il progetto",
        variant: "destructive"
      });
      
      return false;
    }
  };

  // Load project from history
  const loadProject = async (projectId: string): Promise<boolean> => {
    try {
      const loadedProject = getSavedProjectById(projectId);
      
      if (loadedProject) {
        setProject(loadedProject);
        
        toast({
          title: "Progetto caricato",
          description: "Il progetto è stato caricato correttamente",
          variant: "success"
        });
        
        return true;
      }
      
      toast({
        title: "Errore",
        description: "Progetto non trovato",
        variant: "destructive"
      });
      
      return false;
    } catch (error) {
      console.error("Error loading project:", error);
      
      toast({
        title: "Errore",
        description: "Impossibile caricare il progetto",
        variant: "destructive"
      });
      
      return false;
    }
  };

  // Create a new project
  const newProject = () => {
    if (confirm("Vuoi creare un nuovo progetto? I dati non salvati andranno persi.")) {
      setProject(createNewProject());
      
      toast({
        title: "Nuovo progetto",
        description: "È stato creato un nuovo progetto",
        variant: "default"
      });
    }
  };

  // Export project as PDF
  const exportPdf = () => {
    // Ensure calculations are up to date
    calculateProject();
    
    // Generate PDF
    generatePDF(project);
    
    toast({
      title: "PDF Esportato",
      description: "Il PDF è stato generato correttamente",
      variant: "success"
    });
  };

  return (
    <ProjectContext.Provider
      value={{
        project,
        setProject,
        updateProject,
        addRoom,
        deleteRoom,
        duplicateRoom,
        updateRoom,
        addMeasurement,
        deleteMeasurement,
        updateMeasurement,
        toggleCeiling,
        calculateProject,
        saveProject,
        loadProject,
        newProject,
        exportPdf,
        isOnline
      }}
    >
      {children}
    </ProjectContext.Provider>
  );
}
