import { pgTable, text, serial, integer, jsonb, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Base user schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Project schema
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  client: text("client"),
  address: text("address"),
  date: text("date"),
  data: jsonb("data").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;

// Define custom schemas for validating project structure
export const measurementSchema = z.object({
  id: z.string(),
  name: z.string().optional(),
  length: z.number().min(0),
  height: z.number().min(0),
  deductions: z.number().min(0),
  isCeiling: z.boolean().default(false),
  area: z.number().min(0).optional(),
});

export const roomSchema = z.object({
  id: z.string(),
  name: z.string().default("Nuova Stanza"),
  measurements: z.array(measurementSchema).default([]),
  wallArea: z.number().min(0).optional(),
  ceilingArea: z.number().min(0).optional(),
  totalArea: z.number().min(0).optional(),
  materials: z.object({
    bags: z.number().min(0).optional(),
    cost: z.number().min(0).optional(),
  }).optional(),
});

export const projectDataSchema = z.object({
  name: z.string().default("Nuovo Progetto"),
  client: z.string().default(""),
  address: z.string().default(""),
  date: z.string().default(""),
  materials: z.object({
    type: z.string().default("standard"),
    thickness: z.number().default(15),
    price: z.number().default(8.5),
    yield: z.number().default(1.6),
  }),
  rooms: z.array(roomSchema).default([]),
  totalArea: z.number().min(0).optional(),
  totalBags: z.number().min(0).optional(),
  totalCost: z.number().min(0).optional(),
});

export type ProjectData = z.infer<typeof projectDataSchema>;
export type Room = z.infer<typeof roomSchema>;
export type Measurement = z.infer<typeof measurementSchema>;
