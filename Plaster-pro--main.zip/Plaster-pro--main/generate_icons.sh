#!/bin/bash

# Crea la directory per le icone se non esiste
mkdir -p client/public/icons

# Crea un'immagine base con sfondo blu e un testo bianco
# Utilizziamo un gradiente blu per rendere l'icona più attraente
convert -size 512x512 \
  -define gradient:angle=45 \
  gradient:'#4299e1-#3182ce' \
  -gravity center \
  -font DejaVu-Sans-Bold \
  -pointsize 180 \
  -fill white \
  -annotate 0 "P" \
  client/public/icons/icon-512x512.png

# Genera icone di diverse dimensioni per la PWA
convert client/public/icons/icon-512x512.png -resize 72x72 client/public/icons/icon-72x72.png
convert client/public/icons/icon-512x512.png -resize 96x96 client/public/icons/icon-96x96.png
convert client/public/icons/icon-512x512.png -resize 128x128 client/public/icons/icon-128x128.png
convert client/public/icons/icon-512x512.png -resize 144x144 client/public/icons/icon-144x144.png
convert client/public/icons/icon-512x512.png -resize 152x152 client/public/icons/icon-152x152.png
convert client/public/icons/icon-512x512.png -resize 192x192 client/public/icons/icon-192x192.png
convert client/public/icons/icon-512x512.png -resize 384x384 client/public/icons/icon-384x384.png

# Genera schermate splash per iOS
# iPhone 5, SE (1st generation)
convert -size 640x1136 \
  -define gradient:angle=45 \
  gradient:'#4299e1-#3182ce' \
  -gravity center \
  -font DejaVu-Sans-Bold \
  -pointsize 100 \
  -fill white \
  -annotate 0 "PLASTER PRO" \
  client/public/icons/splash-640x1136.png

# iPhone 6, 6s, 7, 8, SE (2nd generation)
convert -size 750x1334 \
  -define gradient:angle=45 \
  gradient:'#4299e1-#3182ce' \
  -gravity center \
  -font DejaVu-Sans-Bold \
  -pointsize 100 \
  -fill white \
  -annotate 0 "PLASTER PRO" \
  client/public/icons/splash-750x1334.png

# iPhone 6+, 6s+, 7+, 8+
convert -size 1242x2208 \
  -define gradient:angle=45 \
  gradient:'#4299e1-#3182ce' \
  -gravity center \
  -font DejaVu-Sans-Bold \
  -pointsize 120 \
  -fill white \
  -annotate 0 "PLASTER PRO" \
  client/public/icons/splash-1242x2208.png

# iPhone X, XS, 11 Pro, 12 mini, 13 mini
convert -size 1125x2436 \
  -define gradient:angle=45 \
  gradient:'#4299e1-#3182ce' \
  -gravity center \
  -font DejaVu-Sans-Bold \
  -pointsize 120 \
  -fill white \
  -annotate 0 "PLASTER PRO" \
  client/public/icons/splash-1125x2436.png

# iPad Mini, Air
convert -size 1536x2048 \
  -define gradient:angle=45 \
  gradient:'#4299e1-#3182ce' \
  -gravity center \
  -font DejaVu-Sans-Bold \
  -pointsize 150 \
  -fill white \
  -annotate 0 "PLASTER PRO" \
  client/public/icons/splash-1536x2048.png

# iPad Pro 10.5"
convert -size 1668x2224 \
  -define gradient:angle=45 \
  gradient:'#4299e1-#3182ce' \
  -gravity center \
  -font DejaVu-Sans-Bold \
  -pointsize 150 \
  -fill white \
  -annotate 0 "PLASTER PRO" \
  client/public/icons/splash-1668x2224.png

# iPad Pro 12.9"
convert -size 2048x2732 \
  -define gradient:angle=45 \
  gradient:'#4299e1-#3182ce' \
  -gravity center \
  -font DejaVu-Sans-Bold \
  -pointsize 180 \
  -fill white \
  -annotate 0 "PLASTER PRO" \
  client/public/icons/splash-2048x2732.png

echo "Generazione delle icone completata!"
