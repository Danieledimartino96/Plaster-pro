// vite-sw-config.ts
import { VitePWA } from 'vite-plugin-pwa';
import { defineConfig } from 'vite';

export const swPlugin = VitePWA({
  registerType: 'autoUpdate',
  injectRegister: 'auto',
  workbox: {
    globPatterns: ['**/*.{js,css,html,ico,png,svg,jpg,jpeg,json}'],
    cleanupOutdatedCaches: true,
    skipWaiting: true,
    clientsClaim: true,
  },
  includeAssets: [
    'icons/icon-72x72.png',
    'icons/icon-96x96.png',
    'icons/icon-128x128.png',
    'icons/icon-144x144.png',
    'icons/icon-152x152.png',
    'icons/icon-192x192.png',
    'icons/icon-384x384.png',
    'icons/icon-512x512.png',
    'icons/splash-640x1136.png',
    'icons/splash-750x1334.png',
    'icons/splash-1242x2208.png',
    'icons/splash-1125x2436.png',
    'icons/splash-1536x2048.png',
    'icons/splash-1668x2224.png',
    'icons/splash-2048x2732.png',
  ],
  manifest: {
    name: 'PLASTER PRO | Calcolo Intonaci',
    short_name: 'PLASTER PRO',
    description: 'Applicazione professionale per il calcolo degli intonaci',
    theme_color: '#3b82f6',
    background_color: '#ffffff',
    display: 'standalone',
    orientation: 'portrait',
    scope: '/',
    start_url: '/',
    icons: [
      {
        src: 'icons/icon-72x72.png',
        sizes: '72x72',
        type: 'image/png'
      },
      {
        src: 'icons/icon-96x96.png',
        sizes: '96x96',
        type: 'image/png'
      },
      {
        src: 'icons/icon-128x128.png',
        sizes: '128x128',
        type: 'image/png'
      },
      {
        src: 'icons/icon-144x144.png',
        sizes: '144x144',
        type: 'image/png'
      },
      {
        src: 'icons/icon-152x152.png',
        sizes: '152x152',
        type: 'image/png'
      },
      {
        src: 'icons/icon-192x192.png',
        sizes: '192x192',
        type: 'image/png'
      },
      {
        src: 'icons/icon-384x384.png',
        sizes: '384x384',
        type: 'image/png'
      },
      {
        src: 'icons/icon-512x512.png',
        sizes: '512x512',
        type: 'image/png'
      }
    ]
  }
});