# PLASTER PRO | Calcolo Intonaci

Un'applicazione web per il calcolo degli intonaci con funzionalità offline, salvataggio progetti e calcolo costi materiali.

## Caratteristiche

- Calcolo preciso delle superfici da intonacare
- Gestione delle misurazioni per stanza
- Calcolo automatico dei materiali necessari
- Ricerca automatica delle informazioni sui materiali (resa al mq, prezzo)
- Supporto per utilizzo offline come PWA (Progressive Web App)
- Interfaccia in stile iOS per un'esperienza utente nativa
- Salvataggio locale dei progetti
- Esportazione dei preventivi in PDF

## Tecnologie

- React con TypeScript
- Tailwind CSS per lo styling
- ShadCN UI per i componenti
- PostgreSQL per la persistenza dei dati
- Service Worker per funzionalità offline
- Progressive Web App per l'installazione su dispositivi mobili
