import { db } from './db';
import { users, projects } from '../shared/schema';
import { sql } from 'drizzle-orm';

async function main() {
  console.log('🔄 Inizio migrazione del database...');
  
  try {
    // Creiamo la tabella users se non esiste
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS "users" (
        "id" SERIAL PRIMARY KEY,
        "username" TEXT NOT NULL UNIQUE,
        "email" TEXT NOT NULL UNIQUE,
        "password_hash" TEXT NOT NULL,
        "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
      );
    `);
    
    // Creiamo la tabella projects se non esiste
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS "projects" (
        "id" SERIAL PRIMARY KEY,
        "user_id" INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        "name" TEXT NOT NULL,
        "client" TEXT,
        "data" TEXT NOT NULL,
        "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
        "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
      );
    `);
    
    console.log('✅ Migrazione completata con successo!');
  } catch (error) {
    console.error('❌ Errore durante la migrazione:', error);
    process.exit(1);
  }
}

main();