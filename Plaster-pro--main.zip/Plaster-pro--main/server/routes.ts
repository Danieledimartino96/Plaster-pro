import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProjectSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  const apiRouter = express.Router();
  
  // Get all projects (demo - no authentication)
  apiRouter.get("/projects", async (req, res) => {
    try {
      // Using placeholder user ID 1 since we don't have authentication
      const projects = await storage.getProjectsByUserId(1);
      return res.json(projects);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  // Get a specific project
  apiRouter.get("/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid project ID" });
      }

      const project = await storage.getProject(id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      return res.json(project);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  // Create a new project
  apiRouter.post("/projects", async (req, res) => {
    try {
      const result = insertProjectSchema.safeParse(req.body);
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      // Set userId to 1 for demo purposes
      const projectWithUserId = { ...result.data, userId: 1 };
      const newProject = await storage.createProject(projectWithUserId);
      return res.status(201).json(newProject);
    } catch (error) {
      return res.status(500).json({ message: "Failed to create project" });
    }
  });

  // Update a project
  apiRouter.put("/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid project ID" });
      }

      const result = insertProjectSchema.partial().safeParse(req.body);
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }

      const updatedProject = await storage.updateProject(id, result.data);
      if (!updatedProject) {
        return res.status(404).json({ message: "Project not found" });
      }

      return res.json(updatedProject);
    } catch (error) {
      return res.status(500).json({ message: "Failed to update project" });
    }
  });

  // Delete a project
  apiRouter.delete("/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid project ID" });
      }

      const success = await storage.deleteProject(id);
      if (!success) {
        return res.status(404).json({ message: "Project not found" });
      }

      return res.json({ success: true });
    } catch (error) {
      return res.status(500).json({ message: "Failed to delete project" });
    }
  });

  app.use("/api", apiRouter);

  const httpServer = createServer(app);
  return httpServer;
}
